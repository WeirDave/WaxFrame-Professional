// ============================================================
//  WaxFrame — storage.js
//  Build: 20260516-011
//
//  COMPLETE storage layer. All WaxFrame state persistence lives
//  here as of v3.48.0:
//    • Primitives (v3.45.0): LS_* keys, IDB helpers, checkStorageQuota
//    • Session persistence (v3.46.0): saveSession, loadSession,
//      _saveSessionChain
//    • Settings persistence (v3.47.0): saveHive, saveProject,
//      loadSettings, snapshotReferenceDocs
//    • Backup + restore (v3.48.0): backupSession, importSession
//
//  Contents:
//    LS_HIVE, LS_PROJECT, LS_SESSION, LS_SETTINGS, LS_LICENSE
//                          — localStorage key constants. Top-level
//                            consts — accessible cross-script via
//                            global lexical environment lookup.
//
//    IDB_NAME, IDB_VERSION, IDB_STORE, IDB_KEY
//                          — IndexedDB schema constants.
//
//    idbOpen()             — open/create the WaxFrame IDB database.
//                            Returns a Promise<IDBDatabase>.
//    idbSet(value)         — atomically write the session payload
//                            under IDB_KEY. Returns Promise<void>.
//    idbGet()              — read the session payload. Returns
//                            Promise<object|null>.
//    idbClear()            — delete the session payload.
//    checkStorageQuota()   — proactive warning when storage is
//                            >=80% full. Surfaces an inline export
//                            button into the Live Console.
//
//  Load order: AFTER version.js (no hard runtime dependency), BEFORE
//  app.js (saveSession / loadSession / saveHive / saveProject /
//  loadSettings in app.js all call into these primitives).
//
//  External dependencies (live in app.js — storage.js calls them
//  at runtime):
//    consoleLog          — Live Console output (used by checkStorageQuota)
//    exportTranscript    — wired as onclick for the quota-warn button
//
//  Cross-script visibility:
//    All `const` declarations and `function` declarations at the
//    top of a classic script are visible to other scripts in the
//    same document via the global lexical environment / global
//    Object Environment Record. Bare-identifier references in
//    app.js (e.g. `localStorage.getItem(LS_HIVE)`) resolve here.
// ============================================================

// ── localStorage KEYS ──
window.LS_HIVE     = 'waxframe_v2_hive';      // AI list + API keys — persistent across projects
window.LS_PROJECT  = 'waxframe_v2_project';   // project name/version/goal/docTab — per project
window.LS_SESSION  = 'waxframe_v2_session';   // round state — per session
window.LS_SETTINGS = 'waxframe_v2_settings';  // legacy key — migrated on first load
window.LS_LICENSE  = 'waxframe_v2_license';   // license key — persistent

// ── INDEXEDDB SESSION STORAGE ──
// Session data (history, docText, consoleHTML) lives in IndexedDB — no size limits.
// localStorage keeps a lightweight 'session exists' flag for fast resume detection.
const IDB_NAME    = 'waxframe_v2_db';
const IDB_VERSION = 1;
const IDB_STORE   = 'session';
const IDB_KEY     = 'current';

let _idb = null; // holds the open IDBDatabase instance

function idbOpen() {
  return new Promise((resolve, reject) => {
    if (_idb) { resolve(_idb); return; }
    const req = indexedDB.open(IDB_NAME, IDB_VERSION);
    req.onupgradeneeded = e => {
      const db = e.target.result;
      if (!db.objectStoreNames.contains(IDB_STORE)) {
        db.createObjectStore(IDB_STORE);
      }
    };
    req.onsuccess = e => { _idb = e.target.result; resolve(_idb); };
    req.onerror   = e => reject(e.target.error);
  });
}

async function idbSet(value) {
  const db = await idbOpen();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(IDB_STORE, 'readwrite');
    tx.objectStore(IDB_STORE).put(value, IDB_KEY);
    tx.oncomplete = () => resolve(true);
    tx.onerror    = e => reject(e.target.error);
  });
}

async function idbGet() {
  const db = await idbOpen();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(IDB_STORE, 'readonly');
    const req = tx.objectStore(IDB_STORE).get(IDB_KEY);
    req.onsuccess = e => resolve(e.target.result || null);
    req.onerror   = e => reject(e.target.error);
  });
}

async function idbClear() {
  const db = await idbOpen();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(IDB_STORE, 'readwrite');
    tx.objectStore(IDB_STORE).delete(IDB_KEY);
    tx.oncomplete = () => resolve(true);
    tx.onerror    = e => reject(e.target.error);
  });
}

async function checkStorageQuota() {
  if (!navigator.storage?.estimate) return;
  try {
    const { usage, quota } = await navigator.storage.estimate();
    const pct = Math.round((usage / quota) * 100);
    if (pct >= 80) {
      consoleLog(`⚠️ Storage is ${pct}% full (${Math.round(usage/1024/1024)}MB of ${Math.round(quota/1024/1024)}MB used). Consider exporting your session to avoid data loss.`, 'warn');
      // Inject an inline export button into the console
      const el = document.getElementById('liveConsole');
      if (el) {
        const existing = el.querySelector('.quota-warn-btn');
        if (!existing) {
          const btn = document.createElement('button');
          btn.className = 'btn quota-warn-btn';
          btn.textContent = '💾 Export Transcript Now';
          btn.onclick = exportTranscript;
          el.prepend(btn);
        }
      }
    }
  } catch(e) {
    // v3.29.2 — was silent. Best-effort; logging so a quiet failure here
    // (browser API quirk) is at least diagnosable.
    console.warn('[checkStorageQuota] failed:', e);
  }
}


/* =============================================================
   SESSION PERSISTENCE  (extracted from app.js v3.46.0)
   ============================================================= */
// ── (v3.21.9) Save serialization chain ──
// Every saveSession() awaits the previous one through this chain so two saves
// in flight can't race on the read-check-write guard inside.
let _saveSessionChain = Promise.resolve();

function saveSession() {
  const consoleEl = document.getElementById('liveConsole');
  const consoleHTML = consoleEl ? consoleEl.innerHTML : '';
  const notesEl = document.getElementById('workNotes');
  const notes = notesEl ? notesEl.value : '';
  // v3.36.17 — Standing notes persist across rounds (one-shot still
  // auto-clears after Builder). Read alongside the one-shot buffer
  // and write to the same session payload. Pre-v3.36.17 sessions
  // have no standingNotes field; loadSession defaults to empty.
  const standingNotesEl = document.getElementById('workStandingNotes');
  const standingNotes = standingNotesEl ? standingNotesEl.value : '';
  // v3.32.18 — Persist the length-guard override flag alongside the rest
  // of the session payload. Set when the user picks "Continue anyway"
  // from the length-guard modal; persisted so it survives reloads
  // mid-project; cleared on clearProject() so a new project starts with
  // the guard active again.
  const lengthGuardOverride = !!window._lengthGuardOverride;
  // v3.32.24 — Persist the per-round satisfaction set so the green-
  // border + ★ state survives page reloads. The Set tracks which AIs
  // returned NO CHANGES NEEDED for the current round; without
  // persistence the Set rebuilds empty on reload and the rehydration
  // path in renderBeeStatusGrid has nothing to walk, so previously-
  // satisfied cards lose their star until the next round runs.
  // Serialized as an array (Sets aren't JSON-friendly) and restored
  // back into a Set on loadSession.
  const cleanThisRound = Array.from(window._cleanThisRound || []);
  // v3.32.26 — Persist the per-session AI toggle set. This is the
  // user's "which AIs are turned on for this round" selection,
  // distinct from `activeAIs` (which AIs are configured in the hive
  // at all — that's persisted via saveHive). Without persistence
  // the user's checkbox toggles on the work-screen hive cards reset
  // to all-on every page reload because initWorkScreen unconditionally
  // re-initialized the Set. Same array-then-Set serialization shape
  // as cleanThisRound.
  const sessionAIs = Array.from(window.sessionAIs || []);
  // v3.36.7 — Persist Deep Dive forensic capture alongside session payload.
  // ringBuffer holds the last RING_MAX (200) per-round captures when Deep
  // Dive is on; lastFailure holds the most recent troubleshooting context
  // (always-on, lightweight). Both flow into backup JSONs automatically
  // via IDB_SESSION serialization, so when David inspects a backup the
  // forensic record is already there — no separate export step needed.
  // ringBuffer is captured by reference but JSON-serialized at idbSet
  // time, so we don't snapshot here; if the buffer mutates between this
  // line and the actual write the latest contents win, which is what
  // we want.
  const ringBuffer  = Array.isArray(WF_DEBUG?.ringBuffer)  ? WF_DEBUG.ringBuffer  : [];
  const lastFailure = WF_DEBUG?.lastFailure || null;
  const session = { round, phase, history, docText, consoleHTML, notes, standingNotes, projClockSeconds: _projClockSeconds, lengthGuardOverride, cleanThisRound, sessionAIs, ringBuffer, lastFailure };

  // Chain through previous save so writes serialize and never overlap.
  _saveSessionChain = _saveSessionChain.then(async () => {
    // ── Primary: IndexedDB (no size limit) ──
    try {
      await idbSet(session);
      try { localStorage.setItem('waxframe_v2_session_exists', '1'); } catch(e) {}
      checkStorageQuota();

      // Persistent-storage retry every 3 rounds if not yet granted.
      if (history.length > 0 && history.length % 3 === 0 &&
          !window._storagePersistent && navigator.storage?.persist) {
        try {
          window._storagePersistent = await navigator.storage.persist();
        } catch(e) { /* ignore */ }
      }
    } catch(e) {
      // IDB failed — fall back to localStorage.
      consoleLog(`❌ Session save failed (IndexedDB error: ${e.message}). Trying localStorage fallback…`, 'error', {
        status:  'IDB_ERROR',
        rawJson: e.stack || e.message || String(e)
      });
      try {
        localStorage.setItem(LS_SESSION, JSON.stringify(session));
        try { localStorage.setItem('waxframe_v2_session_exists', '1'); } catch(ee) {}
      } catch(lsErr) {
        if (lsErr.name === 'QuotaExceededError') {
          consoleLog(`❌ Storage full — session could not be saved. Export your session now to avoid losing work.`, 'error', {
            status:  'QUOTA_EXCEEDED',
            rawJson: `Browser storage quota exceeded.\n\nAction: click "Export Transcript Now" below, then clear browser storage for this site, then reload.\n\nOriginal error: ${lsErr.message}`
          });
          const el = document.getElementById('liveConsole');
          if (el) {
            const existing = el.querySelector('.quota-warn-btn');
            if (!existing) {
              const btn = document.createElement('button');
              btn.className = 'btn quota-warn-btn';
              btn.textContent = '💾 Export Transcript Now';
              btn.onclick = exportTranscript;
              el.prepend(btn);
            }
          }
        } else {
          consoleLog(`❌ Session save failed: ${lsErr.message}`, 'error', {
            status:  'STORAGE_FAIL',
            rawJson: lsErr.stack || lsErr.message || String(lsErr)
          });
        }
      }
    }
  });

  saveProject(); // keep project fields in sync (synchronous, doesn't need to be in the chain)
}

async function loadSession() {
  // Eviction detection: if the session_exists flag is set in localStorage
  // but no actual data is recoverable, the browser silently evicted our
  // IndexedDB store between visits. Capture this so DOMContentLoaded can
  // surface a clear warning to the user instead of dumping them at the
  // welcome screen with no explanation.
  const _hadSessionFlag = localStorage.getItem('waxframe_v2_session_exists') === '1';
  try {
    // Primary: try IndexedDB first
    let s = await idbGet();

    // Fallback: try legacy localStorage key (handles sessions saved before IDB migration)
    if (!s) {
      const raw = localStorage.getItem(LS_SESSION);
      if (raw) {
        s = JSON.parse(raw);
        // Migrate to IndexedDB and clean up localStorage
        idbSet(s).then(() => {
          localStorage.removeItem(LS_SESSION);
          try { localStorage.setItem('waxframe_v2_session_exists', '1'); } catch(e) {}
        }).catch(() => {});
      }
    }

    if (!s) {
      if (_hadSessionFlag) {
        window._sessionEvicted = true;
        localStorage.removeItem('waxframe_v2_session_exists');
      }
      return false;
    }

    round   = s.round   || 1;
    phase   = s.phase   || 'draft';
    history = s.history || [];
    docText = s.docText || '';
    if (s.projClockSeconds) _projClockSeconds = s.projClockSeconds;
    // v3.32.18 — Restore length-guard override flag. Default false for
    // pre-v3.32.18 sessions where the field doesn't exist.
    window._lengthGuardOverride = !!s.lengthGuardOverride;
    // v3.32.28 — #6c indicator state follows the restored flag. The
    // indicator element may not yet be in DOM at first call (e.g.
    // during pre-launch verify); the helper short-circuits cleanly
    // and initWorkScreen re-runs it once the work screen mounts.
    updateLengthGuardIndicator?.();
    // v3.32.24 — Restore per-round satisfaction set. Defaults to empty
    // for pre-v3.32.24 sessions where the field doesn't exist. The
    // Set is reconstructed from the serialized array; the rehydration
    // path in renderBeeStatusGrid (added v3.32.14) then walks it to
    // re-apply is-clean state on each card after the DOM is built.
    window._cleanThisRound = new Set(Array.isArray(s.cleanThisRound) ? s.cleanThisRound : []);
    // v3.32.26 — Restore per-session AI toggle set. Pre-v3.32.26
    // sessions don't have this field; in that case leave window.sessionAIs
    // undefined so initWorkScreen's reset path takes over and seeds it
    // with all activeAIs (which is the historical default behavior).
    if (Array.isArray(s.sessionAIs)) {
      window.sessionAIs = new Set(s.sessionAIs);
    }
    // v3.36.7 — Restore Deep Dive forensic capture. Pre-v3.36.7 sessions
    // don't have these fields; defaults preserve the post-fresh-load
    // state (empty buffer, no lastFailure). When Deep Dive is currently
    // off we still restore the buffer so a backup taken with Deep Dive
    // on retains its captures across reloads — toggling Deep Dive off
    // mid-session will still wipe the buffer (setDeepDive(off) clears
    // it), but reload alone preserves it.
    if (Array.isArray(s.ringBuffer)) {
      WF_DEBUG.ringBuffer = s.ringBuffer;
    }
    if (s.lastFailure && typeof s.lastFailure === 'object') {
      WF_DEBUG.lastFailure = s.lastFailure;
    }
    if (docText && phase === 'draft' && round > 1) phase = 'refine';
    if (s.notes) {
      const notesEl = document.getElementById('workNotes');
      if (notesEl) { notesEl.value = s.notes; updateNotesBtnPriority(); }
    }
    // v3.36.17 — Standing notes restore. Pre-v3.36.17 sessions don't
    // have this field; we leave the standing textarea empty (the
    // user's existing one-shot buffer migrates as-is into the new
    // one-shot field, which is the same DOM id #workNotes).
    if (s.standingNotes) {
      const standingEl = document.getElementById('workStandingNotes');
      if (standingEl) standingEl.value = s.standingNotes;
    }
    // Restore console HTML synchronously — inline with the rest of state
    // restore so there is no async gap between load and render during which
    // the DOM's default console HTML could be captured by an errant saveSession.
    if (s.consoleHTML) {
      const consoleEl = document.getElementById('liveConsole');
      if (consoleEl) consoleEl.innerHTML = s.consoleHTML;
    }
    return true;
  } catch(e) {
    // Last resort: try localStorage directly
    try {
      const raw = localStorage.getItem(LS_SESSION);
      if (!raw) return false;
      const s = JSON.parse(raw);
      round   = s.round   || 1;
      phase   = s.phase   || 'draft';
      history = s.history || [];
      docText = s.docText || '';
      if (s.projClockSeconds) _projClockSeconds = s.projClockSeconds;
      // v3.32.18 — fallback path also restores the override flag.
      window._lengthGuardOverride = !!s.lengthGuardOverride;
      // v3.32.28 — #6c indicator state follows restored flag (fallback path).
      updateLengthGuardIndicator?.();
      // v3.32.24 — fallback path also restores the satisfaction set.
      window._cleanThisRound = new Set(Array.isArray(s.cleanThisRound) ? s.cleanThisRound : []);
      // v3.32.26 — fallback path also restores the session toggle set.
      if (Array.isArray(s.sessionAIs)) {
        window.sessionAIs = new Set(s.sessionAIs);
      }
      // v3.36.7 — fallback path also restores Deep Dive forensic capture.
      if (Array.isArray(s.ringBuffer)) {
        WF_DEBUG.ringBuffer = s.ringBuffer;
      }
      if (s.lastFailure && typeof s.lastFailure === 'object') {
        WF_DEBUG.lastFailure = s.lastFailure;
      }
      if (docText && phase === 'draft' && round > 1) phase = 'refine';
      // Restore console HTML in the fallback path too (see main path)
      if (s.consoleHTML) {
        const consoleEl = document.getElementById('liveConsole');
        if (consoleEl) consoleEl.innerHTML = s.consoleHTML;
      }
      return true;
    } catch(e2) { return false; }
  }
}


/* =============================================================
   REFERENCE DOCS SNAPSHOT  (extracted from app.js v3.47.0)
   Tiny helper used by saveSession for history capture.
   ============================================================= */
// Snapshot reference docs for history capture — returns a deep-enough copy
// so later edits to the live referenceDocs array don't mutate historical entries.
function snapshotReferenceDocs() {
  return referenceDocs.map(d => ({ ...d }));
}


/* =============================================================
   SETTINGS PERSISTENCE — split storage  (extracted v3.47.0)
   saveHive    — AI list + API keys, persistent across projects
   saveProject — project name/version/goal/docTab, per project
   loadSettings — boot-path read of both, with legacy migration
   ============================================================= */
// saveHive — AI list + keys — persistent forever
function saveHive() {
  const keys = {};
  const models = {};
  const customAIConfigs = {};
  const customAIIds = new Set(
    aiList.filter(a => !DEFAULT_AIS.find(d => d.id === a.id)).map(a => a.provider)
  );
  Object.keys(API_CONFIGS).forEach(id => {
    if (API_CONFIGS[id]._key) keys[id] = API_CONFIGS[id]._key;
    if (API_CONFIGS[id].model) models[id] = API_CONFIGS[id].model;
    if (customAIIds.has(id)) {
      const { _key, ...rest } = API_CONFIGS[id];
      customAIConfigs[id] = rest;
    }
  });
  const hive = {
    activeAIIds:     activeAIs.map(a => a.id),
    knownDefaultIds: DEFAULT_AIS.map(d => d.id),
    hiveMode:        _hiveMode,
    builder,
    keys,
    models,
    customAIs: aiList.filter(a => !DEFAULT_AIS.find(d => d.id === a.id)),
    customAIConfigs
  };
  try { localStorage.setItem(LS_HIVE, JSON.stringify(hive)); } catch(e) { console.warn('[saveHive] write failed:', e); }
  updateSetupRequirements();
}

// saveProject — project name/version/goal/docTab — cleared per project
function saveProject() {
  const proj = {
    projectName:    document.getElementById('projectName')?.value    || '',
    projectVersion: document.getElementById('projectVersion')?.value || '',
    goalDocType:    document.getElementById('goalDocType')?.value    || '',
    goalAudience:   document.getElementById('goalAudience')?.value   || '',
    goalOutcome:    document.getElementById('goalOutcome')?.value    || '',
    goalScope:      document.getElementById('goalScope')?.value      || '',
    goalTone:       document.getElementById('goalTone')?.value       || '',
    goalNotes:      document.getElementById('goalNotes')?.value      || '',
    exportMask:     document.getElementById('exportMask')?.value     || '',
    lengthMode:     getLengthMode(),
    lengthLimit:    document.getElementById('lengthLimit')?.value    || '',
    lengthMin:      document.getElementById('lengthMin')?.value      || '',
    lengthUnit:     document.getElementById('lengthUnit')?.value     || 'characters',
    docTab,
    pastedDocument: document.getElementById('pasteText')?.value || '',
    referenceDocs: snapshotReferenceDocs(),
  };
  try { localStorage.setItem(LS_PROJECT, JSON.stringify(proj)); } catch(e) { console.warn('[saveProject] write failed:', e); }
  updateLaunchRequirements();
  updateMaskPreview();
}

function loadSettings() {
  try {
    // ── Try new split storage first ──
    const hiveRaw = localStorage.getItem(LS_HIVE);
    const projRaw = localStorage.getItem(LS_PROJECT);

    // ── Legacy migration: if old key exists, migrate and delete it ──
    const legacyRaw = localStorage.getItem(LS_SETTINGS);
    if (legacyRaw && !hiveRaw) {
      const s = JSON.parse(legacyRaw);
      // Migrate keys and AI list to LS_HIVE
      const keys = s.keys || {};
      const hive = {
        activeAIIds: s.activeAIIds,
        knownDefaultIds: s.knownDefaultIds || DEFAULT_AIS.map(d => d.id),
        builder: s.builder,
        keys,
        customAIs: (s.customAIs || []).filter(ai =>
          // Only keep custom AIs that aren't duplicates of defaults
          !DEFAULT_AIS.find(d => d.id === ai.id)
        )
      };
      localStorage.setItem(LS_HIVE, JSON.stringify(hive));
      localStorage.removeItem(LS_SETTINGS);
    }

    // ── Load hive (AI list + keys) ──
    const hiveData = localStorage.getItem(LS_HIVE);
    if (!hiveData) return false;
    const h = JSON.parse(hiveData);

    aiList = JSON.parse(JSON.stringify(DEFAULT_AIS));
    // v3.31.0 — hiddenDefaultIds removed. Migrate any existing hidden
    // defaults back into the visible aiList (one-time, silent). Legacy
    // hives with hiddenDefaultIds now load with the full default set.
    // No banner, no toast — by v3.31 the concept of "hidden defaults"
    // simply doesn't exist anymore; pre-v3.31 users just see all 6
    // defaults the next time they open the Worker Bees screen.
    // (No-op today since aiList is already the full DEFAULT_AIS clone;
    // kept for clarity / documentation of the migration intent.)
    if (h.customAIs) {
      h.customAIs.forEach(ai => {
        if (!aiList.find(a => a.id === ai.id)) aiList.push(ai);
        if (!API_CONFIGS[ai.provider] && h.customAIConfigs?.[ai.provider]) {
          API_CONFIGS[ai.provider] = h.customAIConfigs[ai.provider];
        }
        // Functions don't survive JSON — rebuild them if missing
        const cfg = API_CONFIGS[ai.provider];
        if (cfg && typeof cfg.headersFn !== 'function') {
          cfg.headersFn = k => ({ 'Content-Type': 'application/json', 'Authorization': `Bearer ${k}` });
          cfg.bodyFn    = (m, prompt) => JSON.stringify({ model: m, messages: [{ role: 'user', content: prompt }] });
          cfg.extractFn = d => d?.choices?.[0]?.message?.content || '';
        }
      });
    }
    if (h.keys) {
      Object.keys(h.keys).forEach(id => {
        if (API_CONFIGS[id]) API_CONFIGS[id]._key = h.keys[id];
      });
    }
    if (h.models) {
      Object.keys(h.models).forEach(id => {
        if (API_CONFIGS[id]) {
          API_CONFIGS[id].model = h.models[id];
          // Re-sync Gemini endpoint if model was customised
          if (id === 'gemini' && API_CONFIGS[id].endpointFn) {
            API_CONFIGS[id].endpoint = API_CONFIGS[id].endpointFn(h.models[id]);
          }
        }
      });
    }
    if (h.activeAIIds !== undefined) {
      activeAIs = h.activeAIIds.map(id => aiList.find(a => a.id === id)).filter(Boolean);
      DEFAULT_AIS.forEach(d => {
        if (!h.activeAIIds.includes(d.id)) {
          const wasKnown = h.knownDefaultIds && h.knownDefaultIds.includes(d.id);
          if (!wasKnown) activeAIs.push(aiList.find(a => a.id === d.id));
        }
      });
      activeAIs = activeAIs.filter(Boolean);
    } else {
      activeAIs = [...aiList];
    }
    builder = h.builder || null;

    // v3.31.0 — Hive mode load + first-run auto-detect.
    // If the hive was saved by v3.31+, h.hiveMode is set and we honor it.
    // Pre-v3.31 hives don't have it; auto-detect: any custom AI with
    // _modelsEndpoint → server, otherwise internet. Then writes back so
    // subsequent loads skip detection.
    if (h.hiveMode === 'internet' || h.hiveMode === 'server') {
      _hiveMode = h.hiveMode;
    } else {
      const hasServerImport = Object.values(API_CONFIGS).some(c => c && c._modelsEndpoint);
      _hiveMode = hasServerImport ? 'server' : 'internet';
      // Persist immediately so the next load doesn't re-detect.
      try { saveHive(); } catch(e) { /* deferred until later save */ }
    }

    // ── Load project (name/version/goal/docTab) ──
    if (projRaw) {
      const p = JSON.parse(projRaw);
      if (p.projectName)    { const el = document.getElementById('projectName');    if (el) el.value = p.projectName; }
      if (p.projectVersion) { const el = document.getElementById('projectVersion'); if (el) el.value = p.projectVersion; }
      // Load structured goal fields
      if (p.goalDocType)  { const el = document.getElementById('goalDocType');  if (el) el.value = p.goalDocType; }
      if (p.goalAudience) { const el = document.getElementById('goalAudience'); if (el) el.value = p.goalAudience; }
      if (p.goalOutcome)  { const el = document.getElementById('goalOutcome');  if (el) el.value = p.goalOutcome; }
      if (p.goalScope)    { const el = document.getElementById('goalScope');    if (el) el.value = p.goalScope; }
      if (p.goalTone)     { const el = document.getElementById('goalTone');     if (el) el.value = p.goalTone; }
      if (p.goalNotes)    { const el = document.getElementById('goalNotes');    if (el) el.value = p.goalNotes; }
      // Legacy migration: if old single projectGoal field exists, move to goalNotes
      if (p.projectGoal && !p.goalDocType && !p.goalAudience && !p.goalOutcome && !p.goalScope && !p.goalTone && !p.goalNotes) {
        const el = document.getElementById('goalNotes');
        if (el) el.value = p.projectGoal;
      }
      if (p.exportMask)     { const el = document.getElementById('exportMask');     if (el) { el.value = p.exportMask; updateMaskPreview(); } }
      if (p.lengthLimit)    { const el = document.getElementById('lengthLimit');    if (el) el.value = p.lengthLimit; }
      if (p.lengthMin)      { const el = document.getElementById('lengthMin');      if (el) el.value = p.lengthMin; }
      if (p.lengthUnit)     { const el = document.getElementById('lengthUnit');     if (el) el.value = p.lengthUnit; }
      // v3.33.0 migration: pre-v3.33.0 projects have no lengthMode field. If a
      // length limit is set without a mode, coerce to 'hardcap' (preserves prior
      // ceiling-only behavior). Empty limit → 'none'. New projects use the
      // explicit value.
      let _restoreMode = p.lengthMode;
      if (!_restoreMode || !['none','hardcap','target','range'].includes(_restoreMode)) {
        _restoreMode = (p.lengthLimit && parseInt(p.lengthLimit, 10) > 0) ? 'hardcap' : 'none';
      }
      setLengthMode(_restoreMode);
      if (p.lengthLimit || p.lengthMin || p.lengthUnit) updateLengthConstraintHint();
      if (p.docTab) docTab = p.docTab;
      // ── PASTED STARTING DOCUMENT restore (v3.21.14) ──
      // Mirror of reference material restore: paste textarea content was DOM-only
      // and lost on refresh until launch. Persisted to LS_PROJECT, restored here.
      if (typeof p.pastedDocument === 'string') {
        const pasteTa = document.getElementById('pasteText');
        if (pasteTa) {
          pasteTa.value = p.pastedDocument;
          if (typeof updateProjLineNums === 'function') updateProjLineNums('projPasteNums', pasteTa);
        }
      }
      // ── REFERENCE MATERIAL restore (v3.24.0 — multi-doc with v3-format migration) ──
      // v4 (v3.24.0+) stores p.referenceDocs as array of {id, name, text, source, filename}.
      // v3 (v3.21.0–v3.23.4) stored p.referenceMaterial string + p.referenceFilename string.
      // If we see the old shape we convert it to a single-element array so no data is lost.
      if (Array.isArray(p.referenceDocs)) {
        referenceDocs = p.referenceDocs
          .filter(d => d && typeof d === 'object')
          .map(d => ({
            id:       d.id       || generateRefDocId(),
            name:     d.name     || 'Reference',
            text:     d.text     || '',
            source:   d.source === 'upload' ? 'upload' : 'paste',
            filename: d.filename || null,
          }));
      } else if (typeof p.referenceMaterial === 'string' && p.referenceMaterial.trim()) {
        const isUpload = typeof p.referenceFilename === 'string' && p.referenceFilename.trim();
        referenceDocs = [{
          id:       generateRefDocId(),
          name:     isUpload ? p.referenceFilename : 'Reference 1',
          text:     p.referenceMaterial,
          source:   isUpload ? 'upload' : 'paste',
          filename: isUpload ? p.referenceFilename : null,
        }];
      } else {
        referenceDocs = [];
      }
      if (typeof renderReferenceCards === 'function') renderReferenceCards();
      if (typeof updateRefGrandTotals === 'function') updateRefGrandTotals();
      updateGoalCounter();
    }

    return true;
  } catch(e) { return false; }
}


/* =============================================================
   BACKUP + RESTORE  (extracted from app.js v3.48.0)
   Completes storage.js. All WaxFrame state persistence now in one file.

   backupSession — downloads a JSON snapshot of LS_HIVE + LS_PROJECT +
                   LS_SESSION + IDB_SESSION as a time-machine. Format v3.
                   Flushes in-memory state to IDB before reading so the
                   snapshot reflects the live UI state.
   importSession — restores a backup file. Replaces localStorage layers
                   and the IDB session; reloads to apply.
   ============================================================= */
async function backupSession() {
  // v3.35.2 — Flush in-memory state to IDB BEFORE reading the
  // snapshot. Without this, a backup taken while in-memory state
  // hadn't yet been auto-saved to IDB (e.g. immediately after
  // filling out the project setup screens, before any round has
  // run) captured IDB_SESSION: null. Combined with the importSession
  // bug fixed in this release — which silently skipped the IDB write
  // when IDB_SESSION was null — the result was that importing a
  // pre-Round-1 backup left the prior project's Round-N state in
  // IDB to bleed through after reload. A backup must be a true
  // time-machine: capture exactly the state at backup time, restore
  // exactly to that state on import.
  try { await saveSession(); } catch(e) { console.warn('[backup] saveSession flush failed, proceeding with whatever is in IDB:', e); }

  const hive    = localStorage.getItem(LS_HIVE)    || null;
  const project = localStorage.getItem(LS_PROJECT) || null;
  // Legacy localStorage session — almost always null since the IDB migration
  // ran ages ago. Kept for forward compatibility with any unmigrated browser.
  const sessionLS = localStorage.getItem(LS_SESSION) || null;
  // Primary session source: IndexedDB. The session blob (round history, working
  // document, console HTML, notes, project clock seconds) lives in IDB.
  let sessionIDB = null;
  try { sessionIDB = await idbGet(); } catch(e) { /* ignore */ }

  if (!hive && !project && !sessionLS && !sessionIDB) {
    toast('⚠️ Nothing to back up'); return;
  }

  const backup = {
    _waxframe_backup:         true,
    _waxframe_backup_version: 4, // v4 = referenceDocs array (v3.24.0+); v3 = LS mirror removed (v3.21.12+); v2 (v3.21.10/11) included LS_SESSION_MIRROR
    _waxframe_app_version:    typeof APP_VERSION === 'string' ? APP_VERSION : '',
    _waxframe_backup_ts:      Date.now(),
    LS_HIVE:           hive,
    LS_PROJECT:        project,
    LS_SESSION:        sessionLS,
    IDB_SESSION:       sessionIDB,    // ← the actual round data
  };
  const proj     = (() => { try { return JSON.parse(project || '{}'); } catch(e) { return {}; } })();
  // v3.36.13 — Filename pattern aligned with document export, transcript, and
  // deep-dive. Was: `{trunc40}-{trunc10}-WaxFrame-Backup-{stamp}` which
  // truncated mid-word on long project names (e.g. "Brightwater" became
  // "Brightwat") and used a different baseName shape than the other three
  // artifacts. Now: `{baseName}-r{N}-{stamp}-Backup` — no truncation, same
  // r-stamp pattern as transcript/deep-dive (so multiple backups from the
  // same project at different rounds don't collide), and the "WaxFrame-"
  // prefix is dropped since the `_waxframe_backup: true` field inside the
  // JSON plus the `-Backup.json` suffix is enough to self-identify.
  //
  // We read projectName/projectVersion from the in-memory parsed LS_PROJECT
  // (above) rather than calling buildExportName() because backupSession can
  // be triggered from any screen via the nav menu, and buildExportName()
  // depends on `workProjectName` / `workProjectVersion` DOM elements that
  // only exist on the work screen. Reading from LS_PROJECT is screen-
  // independent. The formatting regex mirrors buildExportName's exactly so
  // the baseName matches what document/transcript/deep-dive produce.
  const safeName = (proj.projectName || 'session').replace(/[^a-z0-9]/gi, '-').replace(/-+/g, '-').replace(/^-|-$/g, '');
  const safeVer  = (proj.projectVersion || '').replace(/[^a-z0-9._-]/gi, '');
  const baseName = safeVer ? `${safeName}-${safeVer}` : safeName;
  const totalRoundsForName = Math.max(0, (typeof round !== 'undefined' ? round : 1) - 1);
  // Local-time timestamp: YYYYMMDD-HHmm (matches transcript/deep-dive/build-stamp format)
  const d = new Date();
  const pad = n => String(n).padStart(2, '0');
  const stamp = `${d.getFullYear()}${pad(d.getMonth()+1)}${pad(d.getDate())}-${pad(d.getHours())}${pad(d.getMinutes())}`;
  const filename = `${baseName}-r${totalRoundsForName}-${stamp}-Backup`;
  // Empty-file race fix history:
  // v3.21.19 — Append anchor to DOM, click, remove, defer URL.revokeObjectURL
  //            via setTimeout(..., 1000) to give Chrome's download dispatcher
  //            time to read the blob before the URL becomes invalid. Worked for
  //            the ~41 KB Marco Contractor backup that originally surfaced the
  //            race.
  // v3.21.21 — Bumped the timeout from 1 second to 30 seconds. The 1-second
  //            window was generous for tiny backups but not for real sessions:
  //            a 473 KB RFP-Response backup raced again under v3.21.19,
  //            producing the same 0-byte + filename(1) symptom. Larger blobs
  //            take longer for the dispatcher to read, and 1 second was simply
  //            too tight a margin for any realistic session size. 30 seconds
  //            is ~30× the worst observed case (a 21-round JD backup at
  //            642 KB) and gives the dispatcher 15× safety margin even for
  //            hypothetical 100 MB blobs at slow disk write speeds. Memory
  //            cost of the deferred revoke is negligible — at most a handful
  //            of un-revoked blob URLs in any realistic session.
  const blob = new Blob([JSON.stringify(backup, null, 2)], { type: 'application/json' });
  const url  = URL.createObjectURL(blob);
  const a    = document.createElement('a');
  a.href     = url;
  a.download = `${filename}.json`;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  setTimeout(() => URL.revokeObjectURL(url), 30000);
  closeNavMenu();
  // Confirm what was actually captured so the user knows whether session data
  // is in the file or only project setup.
  const sessionMsg = sessionIDB
    ? ` (${sessionIDB.history?.length || 0} rounds, ${(sessionIDB.docText?.length || 0).toLocaleString()} chars)`
    : ' (project setup only — no session data)';
  toast(`💾 Session backed up${sessionMsg}`);
}

function importSession() {
  const input    = document.createElement('input');
  input.type     = 'file';
  input.accept   = '.json';
  input.onchange = e => {
    const file = e.target.files[0];
    if (!file) return;
    const reader   = new FileReader();
    reader.onload  = async ev => {
      try {
        const data = JSON.parse(ev.target.result);
        if (!data._waxframe_backup) { toast('⚠️ Not a valid WaxFrame backup file'); return; }
        // ── Restore localStorage layers ──
        if (data.LS_HIVE)    localStorage.setItem(LS_HIVE,    data.LS_HIVE);
        if (data.LS_PROJECT) localStorage.setItem(LS_PROJECT, data.LS_PROJECT);
        if (data.LS_SESSION) localStorage.setItem(LS_SESSION, data.LS_SESSION);
        // Note: v2 backups include LS_SESSION_MIRROR but mirror was removed in
        // v3.21.12 / format v3 — IDB_SESSION is now the single source of truth.
        // ── (v3.35.2) IDB write is no longer optional ──
        // Prior versions skipped the IDB write when data.IDB_SESSION
        // was null/missing — leaving any prior session in IDB to
        // bleed through after location.reload(). A backup must be a
        // true time-machine, including the case where the captured
        // state was "from-scratch, no rounds run yet". When
        // IDB_SESSION is null/missing now, we explicitly wipe IDB
        // (and the session-exists flag) so the reload reads the
        // captured project setup against an empty session — which is
        // exactly what was captured.
        let restoredFromIDB = false;
        let wipedToScratch  = false;
        if (data.IDB_SESSION) {
          try {
            await idbSet(data.IDB_SESSION);
            try { localStorage.setItem('waxframe_v2_session_exists', '1'); } catch(_) {}
            restoredFromIDB = true;
          } catch(idbErr) {
            console.error('[importSession] IDB restore failed:', idbErr);
            toast(`⚠️ Project restored but IDB session write failed: ${idbErr.message || idbErr}. See console.`, 14000);
          }
        } else {
          // No session in the backup → captured state was pre-Round-1
          // (or a v1-format pre-v3.21.10 backup). Treat as explicit
          // "reset to from-scratch" rather than as "skip the write".
          try {
            await idbClear();
            localStorage.removeItem('waxframe_v2_session_exists');
            wipedToScratch = true;
          } catch(clearErr) {
            console.error('[importSession] IDB clear failed:', clearErr);
            toast(`⚠️ Project restored but IDB clear failed: ${clearErr.message || clearErr}. Prior session may persist.`, 14000);
          }
        }
        // Diagnostic toast — be explicit about what was captured so users know
        // whether they're getting full state or just project setup.
        const v = data._waxframe_backup_version || 1;
        if (v < 2 && !data.IDB_SESSION) {
          toast('⚠️ Old backup format (pre-v3.21.10) — only project setup + API keys restored, session reset to fresh. Reloading…', 12000);
        } else if (restoredFromIDB) {
          const sh = data.IDB_SESSION?.history?.length || 0;
          const sd = data.IDB_SESSION?.docText?.length || 0;
          toast(`✅ Backup restored — ${sh} round${sh !== 1 ? 's' : ''}, ${sd.toLocaleString()} chars in document. Reloading…`, 6000);
        } else if (wipedToScratch) {
          toast('✅ Backup restored — captured pre-Round-1 state, session reset to fresh. Reloading…', 6000);
        } else {
          toast('✅ Project setup restored — reloading…', 6000);
        }
        setTimeout(() => location.reload(), 1500);
      } catch(e) {
        toast('⚠️ Could not read file — is it a WaxFrame backup?');
      }
    };
    reader.readAsText(file);
  };
  closeNavMenu();
  input.click();
}
