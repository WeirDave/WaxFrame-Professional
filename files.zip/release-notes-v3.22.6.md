# WaxFrame v3.22.6 — Helper-Page Consolidation

**Build:** `20260427-013`
**Released:** April 27, 2026

---

## Overview

Three things in one release: license pill on every helper page footer, menu refinements (work screen + helper pages), and a brand-new helper-page design system that finally makes all five helper pages read as the same product. The largest single helper-page release since the chrome unification work in v3.22.5.

---

## What's new

### License pill on every helper page footer

- New shared `license-helper.js` (160 lines, mirrors in-app license functions)
- Both license modals (entry + manage) on every helper page
- Footer restructured to `[Save as PDF] | [version] | [Licensed] [About]` three-section layout
- Click behavior full parity with work-screen pill: Manage modal when licensed, Entry modal when trialing/expired
- License state shared across work screen + all helper pages via the existing `LS_LICENSE` localStorage key

### Menu refinements

- Main menu: `🔑 Enter License Key` → `🔑 License Key` (shorter, more accurate)
- Helper-page menus restructured from 3 sections to 5: Documentation / Tools / Create Something / Support / Advanced
- Prompt Editor moved from Documentation to Advanced (mirrors in-app menu)
- New Tools section on helper pages contains `🔑 License Key`

### NEW: Helper-pages design system

A new `HELPER-PAGES DESIGN SYSTEM` section at the end of `style.css`. All rules scoped under `.helper-body`. Built on existing theme tokens — automatic dark/light/auto theming.

**Primitives introduced:**

- `.helper-body h1/h2/h3/h4` — consistent heading hierarchy (28/20/16/13px)
- `.helper-body p, ul, ol, li, code, pre` — consistent body text and lists
- `.wf-card` with `.is-accent`, `.is-green`, `.is-amber`, `.is-blue`, `.is-red` modifiers
- `.wf-card-title`, `.wf-card-body` sub-elements
- `.wf-tip` — flex tip block with icon + body
- `.wf-intro` — page-level hero block (logo + headline + intro)
- `.wf-section-divider`, `.wf-section-heading`, `.wf-section-heading-sub`
- `.wf-pill` — small inline label with same color modifiers as `.wf-card`

**Page-specific rich components kept distinct** (different visual job from generic cards):

- `.kyh-card` — AI personality cards on api-details
- `.kyh-badge-builder/reviewer/free` — role badges on KYH cards
- `.kyh-pill-good/warn/bad` — strength/weakness/cost descriptors
- `.ai-card` — AI signup cards on api-details

### Migrations applied to every helper page

| Page | What was migrated |
|------|------|
| `api-details.html` | Inline `<style>` block DELETED. `.info-card` blocks → `.wf-card`. `.kyh-tips-*` block → clean `.wf-card` with `<p><strong>` paragraphs. `.section-title` divs → `<h2>`. `.section-divider` → `.wf-section-divider`. Page title H2 → H1. |
| `what-are-tokens.html` | New H1 + intro added. All `.card.*` → `.wf-card.is-*`. Card `<h3>` → `<h3 class="wf-card-title">`. `.section-title` divs → `<h2>`. "Learn more" block → `.wf-tip`. |
| `document-playbooks.html` | 12 `.dp-tip` blocks → `.wf-tip`. `.dp-intro` → `.wf-intro`. Page-specific `.dp-playbook`, `.dp-field` etc. KEPT. |
| `waxframe-user-manual.html` | 14 `.wh-tip` blocks → `.wf-tip`. `.wh-intro` → `.wf-intro`. `.wh-list` stripped to plain `<ul>`. Page-specific `.wh-section`, `.wh-block`, `.wh-step`, `.wh-warn`, `.wh-tag`, `.wh-back-top`, `.wh-table` KEPT. |
| `prompt-editor.html` | Body NOT migrated — pure tool surface, no narrative content to consolidate. License pill, About modal, menu changes still applied. |

### Dead CSS removed

Orphaned old rules deleted from `style.css`. Each rule was checked for any remaining HTML/JS references before deletion (orphan-by-grep ≠ safe-to-delete, per the v3.21.26 lesson).

**Deleted:** `.section-title`, `.section-divider`, `.section-heading*`, `.card`, `.card.accent/amber/green`, `.card h3/p/strong`, `.info-card`, `.info-card.green`, `.info-card h2/h3/p`, `.info-card-tips`, `.kyh-tips-title/p/strong/p-last`, `.api-intro-title` fallback, `.api-intro-desc` fallback, `.api-azure-intro`, `.helper-note-card`, `.helper-note`, `.card-push-bottom`, `.footer-note`, `.wh-intro` block, `.wh-tip` block, `.dp-intro` block, `.dp-tip` block.

**Kept** (still in use): `.ai-card`, `.ai-card-header`, `.ai-table`, `.wh-section`, `.wh-section-hdr`, `.wh-section-title`, `.wh-block`, `.wh-step`, `.wh-warn`, `.wh-tag`, `.wh-back-top`, `.wh-table`, `.dp-playbook`, `.dp-field`, `.dp-category-*`, `.dp-back-top`, `.kyh-section-title`, `.helper-tip-icon-img`, `.helper-info-img`.

---

## What's *not* in this release

- Work screen, setup screens, welcome screen, in-app About modal contents — all unchanged.
- Helper page section structure or copy — all unchanged. Only chrome and visual presentation touched.
- All `app.js` JavaScript — only `BUILD` constant updated.

---

## Items shipped from the queue

- Helper-page content consistency — five card systems collapsed to one (resolved)
- Five tip systems collapsed to one (resolved)
- api-details inline `<style>` block (rule violation) — closed
- Helper-page H1 missing on three pages — added (resolved)
- License pill on helper pages (resolved)
- Menu refinements (License Key label, Tools section, Prompt Editor in Advanced) — resolved

---

## Validation

- `style.css` brace balance: **1675 / 1675** ✓
- All HTML files div-balanced ✓
- Zero stale class references on any helper page ✓
- All design-system primitives + kept page-specific components have CSS rules ✓
- All canonical stamps at v3.22.6 / `20260427-013` ✓
- All cache-busts at `?v=3.22.6` ✓

---

## Upgrade

Pull and hard-refresh. **`license-helper.js` is a new file — make sure GitHub Desktop adds it to the repo (not just sees modifications).**

---

## Test plan (abbreviated)

1. **License pill** — green ✓ Licensed shows on every helper page footer-right. Click to manage. Replace/remove flows work. Cross-page sync works.
2. **Menu** — main menu shows "License Key" not "Enter License Key". Helper-page menus have 5 sections. Prompt Editor in Advanced.
3. **Footer layout** — `[Save as PDF] | [version] | [Licensed] [About]` on every helper page.
4. **Design system smoke test** — open each helper page, confirm:
   - All cards have left-edge accent stripe (color varies by `.is-*` modifier)
   - All tips render with TipButton icon + italic body + accent-tinted background
   - All page H1s render at 28px bold
   - All section H2s render at 20px bold
   - Lists render with consistent indent and line-height
   - Theme switch (Light/Auto/Dark) propagates correctly
5. **App regression** — `index.html` work screen, setup screens, hamburger menu unchanged from v3.22.5.

---

## What's next

Helper pages are now visually unified, structurally consistent, and built on a primitive system that makes future content additions trivial. Next up is the queued backlog (#7, #13, #14, etc.) or any other priority that becomes pressing.
