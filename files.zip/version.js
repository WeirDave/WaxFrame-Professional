// ============================================================
//  WaxFrame — version.js
//  THE ONLY PLACE the version number lives.
//  Update APP_VERSION here and it propagates to every page.
// ============================================================

const APP_VERSION = 'v3.22.6 Pro';
